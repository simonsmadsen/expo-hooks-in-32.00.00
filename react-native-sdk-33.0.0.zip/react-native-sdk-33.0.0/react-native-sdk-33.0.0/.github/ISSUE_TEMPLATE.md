GitHub Issues in the `facebook/react-native` repository are used exclusively for tracking bugs in React Native.

Please take a look at the issue templates at https://github.com/facebook/react-native/issues/new/choose before submitting a new issue. Following one of the issue templates will ensure maintainers can route your request efficiently. Thanks!
